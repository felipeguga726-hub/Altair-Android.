# A.L.T.A.I.R Android — versão 0.2

Projeto Android nativo em Kotlin, preparado para abrir no Android Studio.

## Implementado nesta versão
- Interface nativa para celular.
- Conversa com a API Groq usando o modelo `openai/gpt-oss-20b` encontrado na configuração de exemplo do projeto original.
- Envio do histórico recente para manter o contexto entre mensagens.
- Histórico local persistente (últimas 16 mensagens) e opção de limpar.
- Armazenamento da chave Groq com `EncryptedSharedPreferences` e chave mestra Android Keystore.
- Mensagens de erro mais claras para chave inválida, limite da API e falhas de conexão.

## Requisitos
- Para compilar na nuvem pelo GitHub Actions: uma conta GitHub e este projeto enviado a um repositório.
- Para compilar localmente: Android Studio recente, JDK 17 e Android SDK Platform 35.
- Para conversar no app: internet e uma chave própria da API Groq.

## Como abrir e testar
1. Extraia o ZIP.
2. Abra a pasta `Altair_Android_Projeto` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação da dependência `androidx.security:security-crypto`.
4. Conecte um Android com depuração USB ou use um emulador.
5. Execute o app, abra Configurações e informe sua chave Groq.

## Limitações conhecidas
- Este pacote é código-fonte, não APK compilado.
- Não foi possível compilar/testar neste ambiente porque não há Android SDK nem Gradle instalados.
- O app precisa de internet e de uma chave Groq válida; o uso está sujeito a disponibilidade, limites e políticas do provedor.
- Voz, reconhecimento de fala, leitura em voz alta, clima e ferramentas matemáticas ainda serão portados em etapas seguintes.
- A API Groq recebe o texto enviado e o contexto da conversa. Não envie dados sensíveis.

## Próximas etapas
Adicionar reconhecimento de fala e resposta falada usando os serviços nativos do Android, com permissões solicitadas em tempo de execução; depois portar clima, ferramentas matemáticas e análise de documentos.

## Gerar o APK pelo GitHub usando apenas o celular
O projeto inclui `.github/workflows/android.yml` para compilar o APK na nuvem.
1. Crie um repositório no GitHub e envie o conteúdo desta pasta para ele.
2. No repositório, abra **Actions**.
3. Selecione **Build Altair Android APK** e toque em **Run workflow** (ou aguarde a compilação após enviar para a branch `main`).
4. Quando terminar, abra a execução concluída e baixe o artefato **Altair-debug-apk**.
5. Extraia o artefato para obter `app-debug.apk` e instale no Android, autorizando a instalação pelo navegador/gerenciador de arquivos se o sistema solicitar.

O APK de depuração serve para testes. Para distribuir publicamente, será necessário preparar uma versão release assinada com segurança.

package com.navik.altair

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.widget.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var history: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var status: TextView
    private lateinit var settings: android.content.SharedPreferences
    private lateinit var securePrefs: android.content.SharedPreferences
    private val conversation = JSONArray()
    private val maxHistoryMessages = 16

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 14, 24)
        window.navigationBarColor = Color.rgb(8, 14, 24)
        settings = getSharedPreferences("altair_chat", MODE_PRIVATE)
        securePrefs = createSecurePreferences()
        restoreConversation()
        buildUi()
        if (conversation.length() == 0) {
            addMessage("A.L.T.A.I.R", "Sistema iniciado. Configure sua chave Groq em Configurações para começar.", false, false)
        }
    }

    private fun createSecurePreferences(): android.content.SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(this)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                this,
                "altair_secure_settings",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // If secure storage cannot initialize, do not silently store credentials in plaintext.
            throw IllegalStateException("Não foi possível iniciar o armazenamento protegido: ${e.message}")
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 10)
            setBackgroundColor(Color.rgb(8, 14, 24))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "A.L.T.A.I.R"; textSize = 22f; setTextColor(Color.rgb(83, 190, 255))
        }
        val clear = Button(this).apply {
            text = "Limpar"; setOnClickListener { clearConversation() }
        }
        val config = Button(this).apply {
            text = "⚙"; contentDescription = "Configurações"; setOnClickListener { settingsDialog() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(clear)
        header.addView(config)
        root.addView(header)
        status = TextView(this).apply {
            text = "ASSISTENTE PESSOAL • ANDROID"; textSize = 10f
            setTextColor(Color.LTGRAY); setPadding(0, 4, 0, 10)
        }
        root.addView(status)
        val scroll = ScrollView(this)
        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(history)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Escreva sua mensagem..."; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(false); maxLines = 4; setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(25, 34, 48))
        }
        send = Button(this).apply { text = "Enviar"; setOnClickListener { sendMessage() } }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(send)
        root.addView(bar)
        setContentView(root)
        renderConversation()
    }

    private fun addMessage(who: String, text: String, user: Boolean, save: Boolean = true) {
        val card = TextView(this).apply {
            this.text = "$who\n$text"; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(if (user) Color.rgb(24, 58, 88) else Color.rgb(28, 38, 52))
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 8) }
        history.addView(card, lp)
        if (save && (who == "Você" || who == "A.L.T.A.I.R")) {
            conversation.put(JSONObject().put("role", if (user) "user" else "assistant").put("content", text))
            trimHistory()
            persistConversation()
        }
    }

    private fun renderConversation() {
        if (!::history.isInitialized) return
        history.removeAllViews()
        for (i in 0 until conversation.length()) {
            val item = conversation.optJSONObject(i) ?: continue
            val isUser = item.optString("role") == "user"
            val who = if (isUser) "Você" else "A.L.T.A.I.R"
            val card = TextView(this).apply {
                text = "$who\n${item.optString("content")}"; textSize = 15f; setTextColor(Color.WHITE)
                setPadding(14, 12, 14, 12)
                setBackgroundColor(if (isUser) Color.rgb(24, 58, 88) else Color.rgb(28, 38, 52))
            }
            history.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 8) })
        }
    }

    private fun trimHistory() {
        while (conversation.length() > maxHistoryMessages) conversation.remove(0)
    }

    private fun persistConversation() {
        settings.edit().putString("conversation", conversation.toString()).apply()
    }

    private fun restoreConversation() {
        val raw = settings.getString("conversation", "[]") ?: "[]"
        try {
            val saved = JSONArray(raw)
            for (i in 0 until saved.length()) {
                val item = saved.optJSONObject(i) ?: continue
                val role = item.optString("role")
                if ((role == "user" || role == "assistant") && item.has("content")) {
                    conversation.put(JSONObject().put("role", role).put("content", item.optString("content")))
                }
            }
            trimHistory()
        } catch (_: Exception) { settings.edit().remove("conversation").apply() }
    }

    private fun clearConversation() {
        AlertDialog.Builder(this)
            .setTitle("Limpar conversa?")
            .setMessage("O histórico salvo neste aparelho será apagado.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Limpar") { _, _ ->
                while (conversation.length() > 0) conversation.remove(0)
                persistConversation()
                renderConversation()
                addMessage("A.L.T.A.I.R", "Histórico limpo. Podemos começar uma nova conversa.", false, false)
            }.show()
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        val key = securePrefs.getString("groq_key", "") ?: ""
        if (key.isBlank()) { settingsDialog(); return }
        addMessage("Você", prompt, true)
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        send.isEnabled = false
        status.text = "ANALISANDO..."
        thread {
            try {
                val response = callGroq(key)
                runOnUiThread {
                    addMessage("A.L.T.A.I.R", response, false)
                    status.text = "CONECTADO • GROQ"
                    send.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    addMessage("Sistema", friendlyError(e), false, false)
                    status.text = "FALHA NA CONEXÃO"
                    send.isEnabled = true
                }
            }
        }
    }

    private fun callGroq(key: String): String {
        val conn = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "system").put("content",
                "Você é A.L.T.A.I.R, um assistente pessoal em português brasileiro. " +
                "Seja claro, analítico, respeitoso e objetivo. Separe fatos confirmados, inferências e hipóteses. " +
                "Quando não souber ou não puder verificar algo, diga isso com transparência."))
            for (i in 0 until conversation.length()) msgs.put(conversation.getJSONObject(i))
            val body = JSONObject()
                .put("model", "openai/gpt-oss-20b")
                .put("messages", msgs)
                .put("temperature", 0.4)
                .put("max_completion_tokens", 1200)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val detail = try { JSONObject(raw).optJSONObject("error")?.optString("message", "") ?: "" } catch (_: Exception) { "" }
                throw ApiException(code, detail.ifBlank { raw.take(300) })
            }
            val content = JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "").trim()
            return content.ifBlank { "A resposta veio vazia. Tente novamente." }
        } finally { conn.disconnect() }
    }

    private fun friendlyError(error: Exception): String = when (error) {
        is ApiException -> when (error.code) {
            401 -> "A chave Groq foi recusada. Confira se ela está correta nas configurações."
            429 -> "O limite de solicitações da API foi atingido. Aguarde um pouco e tente novamente."
            400 -> "A API recusou o pedido: ${error.message}"
            else -> "Erro da API (HTTP ${error.code}): ${error.message}"
        }
        else -> "Não consegui conectar. Verifique a internet e tente novamente. Detalhe: ${error.message ?: "erro desconhecido"}"
    }

    private fun settingsDialog() {
        val field = EditText(this).apply {
            hint = "Cole sua chave Groq (gsk_...)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(securePrefs.getString("groq_key", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("Configurações do A.L.T.A.I.R")
            .setMessage("A chave será armazenada com criptografia protegida pelo Android. Nunca envie sua chave para outras pessoas.")
            .setView(field)
            .setPositiveButton("Salvar") { _, _ ->
                val key = field.text.toString().trim()
                if (key.isBlank()) securePrefs.edit().remove("groq_key").apply()
                else securePrefs.edit().putString("groq_key", key).apply()
                Toast.makeText(this, "Configuração salva", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Remover chave") { _, _ ->
                securePrefs.edit().remove("groq_key").apply()
                Toast.makeText(this, "Chave removida", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private class ApiException(val code: Int, message: String) : Exception(message)
}
